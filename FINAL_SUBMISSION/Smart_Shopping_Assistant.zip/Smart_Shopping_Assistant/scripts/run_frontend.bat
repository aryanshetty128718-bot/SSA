@echo off
echo Starting SSA React/Vite Frontend on http://localhost:5173...
cd frontend
call npm run dev
